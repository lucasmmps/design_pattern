public interface ICalcMedia {
    public double CalculaMedia(double p1, double p2);
    public String Situacao(double media);
}
